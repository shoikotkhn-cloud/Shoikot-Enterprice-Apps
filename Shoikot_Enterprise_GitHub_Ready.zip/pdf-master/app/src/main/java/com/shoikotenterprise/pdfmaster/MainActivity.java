package com.shoikotenterprise.pdfmaster;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView status; boolean bn=false, dark=false;
    static final int PICK_IMAGE=1, CREATE_PDF=2, PICK_PDF=3;
    Bitmap chosen;
    @Override public void onCreate(Bundle b){super.onCreate(b); build();}
    void build(){
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,24);
        root.setBackgroundColor(dark?0xff101827:0xfff3f6fb);
        TextView title=new TextView(this); title.setText("PDF Master"); title.setTextSize(27); title.setTypeface(null,1); title.setTextColor(dark?0xffffffff:0xff172033); root.addView(title);
        TextView sub=new TextView(this); sub.setText("SHOIKOT ENTERPRISE"); sub.setTextColor(dark?0xffb7c9e8:0xff53647d); root.addView(sub);
        Button lang=btn(bn?"Switch to English":"বাংলা",()->{bn=!bn;build();}); root.addView(lang);
        Button theme=btn(dark?"Light Mode":"Dark Mode",()->{dark=!dark;build();}); root.addView(theme);
        addAction(bn?"ছবি থেকে PDF":"Image to PDF",()->pickImage());
        addAction(bn?"PDF থেকে ছবি":"PDF to Image",()->pickPdf());
        addAction(bn?"PDF Merge (পরবর্তী সংস্করণে)":"Merge PDF (next build)",()->msg("PDF merge will be enabled in the next verified build."));
        addAction(bn?"PDF Split (পরবর্তী সংস্করণে)":"Split PDF (next build)",()->msg("PDF split will be enabled in the next verified build."));
        addAction(bn?"PDF Compress (পরবর্তী সংস্করণে)":"Compress PDF (next build)",()->msg("PDF compression will be enabled in the next verified build."));
        status=new TextView(this); status.setText(bn?"অফলাইনে কাজ করুন।":"Works offline. Choose a tool."); status.setTextColor(dark?0xffdce6f5:0xff34445c); status.setPadding(0,24,0,0); root.addView(status);
        ScrollView sc=new ScrollView(this); sc.addView(root); setContentView(sc);
    }
    Button btn(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());return b;}
    void addAction(String s,Runnable r){root.addView(btn(s,r));}
    void msg(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("OK",null).show();}
    void pickImage(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_IMAGE);}
    void pickPdf(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/pdf");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_PDF);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;
        try{
            Uri u=data.getData();
            if(req==PICK_IMAGE){chosen=android.provider.MediaStore.Images.Media.getBitmap(getContentResolver(),u);Intent out=new Intent(Intent.ACTION_CREATE_DOCUMENT);out.setType("application/pdf");out.putExtra(Intent.EXTRA_TITLE,"Shoikot-Image.pdf");startActivityForResult(out,CREATE_PDF);}
            else if(req==PICK_PDF){renderPdf(u);}
            else if(req==CREATE_PDF && chosen!=null){createPdf(data.getData(),chosen);status.setText("PDF saved successfully.");}
        }catch(Exception e){msg("Could not process file: "+e.getMessage());}
    }
    void createPdf(Uri out,Bitmap bmp)throws Exception{PdfDocument d=new PdfDocument();PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(595,842,1).create();PdfDocument.Page page=d.startPage(info);Rect dst=new Rect(20,20,575,822);page.getCanvas().drawBitmap(bmp,null,dst,null);d.finishPage(page);OutputStream os=getContentResolver().openOutputStream(out);d.writeTo(os);os.close();d.close();}
    void renderPdf(Uri uri)throws Exception{ParcelFileDescriptor fd=getContentResolver().openFileDescriptor(uri,"r");android.graphics.pdf.PdfRenderer r=new android.graphics.pdf.PdfRenderer(fd);if(r.getPageCount()==0)throw new Exception("Empty PDF");android.graphics.pdf.PdfRenderer.Page page=r.openPage(0);Bitmap b=Bitmap.createBitmap(page.getWidth()*2,page.getHeight()*2,Bitmap.Config.ARGB_8888);page.render(b,null,null,android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);File f=new File(getExternalFilesDir(null),"pdf-page-1.png");FileOutputStream os=new FileOutputStream(f);b.compress(Bitmap.CompressFormat.PNG,100,os);os.close();page.close();r.close();fd.close();msg("First page exported as PNG to app storage:\n"+f.getAbsolutePath());}
}
