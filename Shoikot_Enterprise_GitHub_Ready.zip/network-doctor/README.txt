Network Doctor – Shoikot Enterprise
Android Studio source project (beta starter)

Open this folder in Android Studio. Use JDK 17 and Android Gradle Plugin 8.7.3.
Let Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
The APK will be under app/build/outputs/apk/debug/.

This source project has not been compiled or device-tested in this environment.
PDF Master currently implements Image-to-PDF and first-page PDF-to-PNG export.
Merge, Split and Compress are visible as planned items but not implemented yet.
Network Doctor includes basic ping reachability, DNS, Wi-Fi/local IP information
and a single-server download estimate. Android may restrict SSID and Wi-Fi fields.

Language and theme controls are simple in-app toggles in this starter build.
Use customer consent, protect personal files, and test with non-sensitive files.
