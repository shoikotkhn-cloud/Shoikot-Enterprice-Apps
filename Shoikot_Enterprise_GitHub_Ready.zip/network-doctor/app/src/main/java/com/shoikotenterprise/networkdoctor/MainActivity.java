package com.shoikotenterprise.networkdoctor;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.*;
import android.net.wifi.*;
import android.view.*;
import android.widget.*;
import java.net.*;
import java.io.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView result; boolean bn=false,dark=false;
    @Override public void onCreate(Bundle b){super.onCreate(b);build();}
    void build(){
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,24,24,24);root.setBackgroundColor(dark?0xff101827:0xfff3f6fb);
        TextView t=new TextView(this);t.setText("Network Doctor");t.setTextSize(27);t.setTypeface(null,1);t.setTextColor(dark?0xffffffff:0xff172033);root.addView(t);
        TextView s=new TextView(this);s.setText("SHOIKOT ENTERPRISE");s.setTextColor(dark?0xffb7c9e8:0xff53647d);root.addView(s);
        add(bn?"English":"বাংলা",()->{bn=!bn;build();});add(dark?"Light Mode":"Dark Mode",()->{dark=!dark;build();});
        add(bn?"Ping পরীক্ষা":"Ping Test",()->runAsync(()->ping()));
        add(bn?"DNS Lookup":"DNS Lookup",()->runAsync(()->dns()));
        add(bn?"Wi-Fi তথ্য":"Wi-Fi Information",()->wifi());
        add(bn?"IP তথ্য":"IP Information",()->ip());
        add(bn?"ইন্টারনেট স্পিড পরীক্ষা":"Internet Speed Test",()->runAsync(()->speed()));
        result=new TextView(this);result.setText(bn?"পরীক্ষা শুরু করতে একটি অপশন বেছে নিন।":"Choose a test.");result.setTextColor(dark?0xffe5edf8:0xff26354a);result.setPadding(0,22,0,0);root.addView(result);
        ScrollView sc=new ScrollView(this);sc.addView(root);setContentView(sc);
    }
    void add(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());root.addView(b);}
    void show(String s){runOnUiThread(()->result.setText(s));}
    void runAsync(Runnable r){new Thread(r).start();}
    void ping(){try{long total=0;int n=4;for(int i=0;i<n;i++){long a=System.nanoTime();boolean ok=InetAddress.getByName("1.1.1.1").isReachable(2500);long ms=(System.nanoTime()-a)/1000000;total+=ms;}show("Ping (approx. ICMP reachability)\nAverage: "+(total/n)+" ms\nNote: some networks block ICMP.");}catch(Exception e){show("Ping error: "+e.getMessage());}}
    void dns(){try{InetAddress[] a=InetAddress.getAllByName("example.com");StringBuilder s=new StringBuilder("DNS: example.com\n");for(InetAddress x:a)s.append(x.getHostAddress()).append("\n");show(s.toString());}catch(Exception e){show("DNS error: "+e.getMessage());}}
    void wifi(){try{WifiManager w=(WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);WifiInfo i=w.getConnectionInfo();show("Wi-Fi enabled: "+w.isWifiEnabled()+"\nSSID: "+i.getSSID()+"\nLink speed: "+i.getLinkSpeed()+" Mbps\nRSSI: "+i.getRssi()+" dBm\nSome fields may be hidden by Android permissions/version.");}catch(Exception e){show("Wi-Fi info unavailable: "+e.getMessage());}}
    void ip(){try{StringBuilder s=new StringBuilder("Local interface addresses:\n");for(java.util.Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces();en.hasMoreElements();){NetworkInterface ni=en.nextElement();for(java.util.Enumeration<InetAddress> ae=ni.getInetAddresses();ae.hasMoreElements();){InetAddress a=ae.nextElement();if(!a.isLoopbackAddress())s.append(ni.getName()).append(": ").append(a.getHostAddress()).append("\n");}}show(s.toString());}catch(Exception e){show("IP error: "+e.getMessage());}}
    void speed(){try{URL u=new URL("https://speed.cloudflare.com/__down?bytes=5000000");long start=System.nanoTime();URLConnection c=u.openConnection();c.setConnectTimeout(10000);c.setReadTimeout(20000);InputStream in=c.getInputStream();byte[] b=new byte[8192];long bytes=0;int n;while((n=in.read(b))!=-1)bytes+=n;in.close();double sec=(System.nanoTime()-start)/1e9;double mbps=(bytes*8.0/sec)/1000000.0;show(String.format("Download test (approx.)\n%.2f Mbps\nDownloaded: %.2f MB\nThis is a single-server estimate.",mbps,bytes/1000000.0));}catch(Exception e){show("Speed test failed: "+e.getMessage());}}
}
